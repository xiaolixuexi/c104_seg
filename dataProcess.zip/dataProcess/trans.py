import cv2
import matplotlib.pyplot as plt


image=cv2.imread("./860_L.jpg",2)  #读取灰度图像
image1=cv2.applyColorMap(image, cv2.COLORMAP_JET)
# image1 = cv2.cvtColor(image,cv2.COLOR_GRAY2BGR)
cv2.imwrite("./860_map.jpg",image1) #保存热力图
