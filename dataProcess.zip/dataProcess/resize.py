import cv2
img = cv2.imread('7_13_label.jpg')
print(img.shape)
h, w = 600, 600
new_img = cv2.resize(img, (h,w))
print('Resized Dimensions : ',new_img.shape)
cv2.imwrite("7_13_label_new.jpg",new_img) #保存