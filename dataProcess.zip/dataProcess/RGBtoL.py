import cv2
import matplotlib.pyplot as plt

img = cv2.imread('./860.jpg')
img1 = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
cv2.imwrite('./860_L.jpg', img1)
